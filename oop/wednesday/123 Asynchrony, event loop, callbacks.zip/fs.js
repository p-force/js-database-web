const fs = require("fs");

fs.writeFile(`file.txt`, `1\n`, () => {
  fs.appendFile(`file.txt`, `2\n`, () => {
    fs.appendFile(`file.txt`, `3\n`, () => {
      fs.appendFile(`file.txt`, `4\n`, () => {
        fs.appendFile(`file.txt`, `5\n`, () => {
          fs.appendFile(`file.txt`, `Ой...\n`, () => { });
        });
      });
    });
  });
});



