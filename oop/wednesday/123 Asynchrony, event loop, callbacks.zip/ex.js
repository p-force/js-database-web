const superTimer = (final) => {
  let count = 0

  const timerID = setInterval(() => {
    count += 1
    console.log(count);

    if (count === final) {
      clearInterval(timerID)
    }
  }, 1000)
}

superTimer(7)