// Читать файл +
// На основе файла добавить эмодзи +
// Записать новый файл с новым контентом +
// Прочитать новый файл +

const fs = require('fs')
const emo = require('./data/emo')
// let masName = []
// // const read = require('')
// const fileName = fs.readFile('./data/names.txt', 'utf-8', () => {
//   fs.writeFile('./data/final.txt', fileName.split('\n').map((el, i) => el+ ' ' + emo[i]).join("\n"))
// });

// not correct!
// const fileName = fs.readFile('./data/names.txt', 'utf-8', () => { })

fs.readFile('./data/names.txt', 'utf-8', (err, data) => {
  if (err) {
    throw new Error('Oops!')
  }

  const newContent = data
    .split('\n')
    .map((name, index) => `${name} сегодня такой(-ая): ${emo[index]}`)
    .join('\n')

  fs.writeFile('./data/newContent.txt', newContent, (err) => {
    if (err) {
      throw new Error('Oops!')
    }


    fs.readFile('./data/newContent.txt', 'utf-8', (err, data) => {
      if (err) {
        throw new Error('Oops!')
      }

      console.log(data);
    })
  })
})

console.log('Студенты:');

