console.log('Step 1');

function one() {
  console.log('Step 2');
}

function two() {
  console.log('Step 2.1');
}

const timer = setTimeout(one, 2000);
setTimeout(two, 1000);

console.log('Step 3');


const timer3 = setInterval(() => {
  console.log(timer3);
  clearInterval(timer3)
}, 2000)

const timer4 = setInterval(print, 3000, "Hello");

function print(message) {
  console.log(message);
  clearTimeout(timer4);
}
