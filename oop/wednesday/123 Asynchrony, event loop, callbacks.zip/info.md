## Timers: setTimeout(), setInterval():
> Таймер setTimeout осуществляет вызов функции или выполнение фрагмента кода после указанной задержки времени, указывают миллисекунды.

Пример 1:
```
// при выполнении setTimeout возвращается ID текущего таймера
setTimeout(() => {
  console.log('Сообщение показано через 5 секунд');
 }, 5000) 
```

Пример 2:
```
const timer = setInterval(() => {
  console.log('Сообщение показывается каждую секунду');
}, 1000)

// метод clearInterval() очищает таймер, тем самым останавливает его выполнение
clearInterval(timer)
```

## EventLoop (событийный цикл):
Идея EventLoop (событийного цикла) очень проста. Есть бесконечный цикл, в котором движок JavaScript ожидает задачи, исполняет их и снова ожидает появления новых.

Общий алгоритм движка:

- Пока есть задачи:
  - выполнить их, начиная с самой старой
- Бездействовать до появления новой задачи, а затем перейти к пункту 1

Это формализация того, что мы наблюдаем, просматривая веб-страницу. Движок JavaScript большую часть времени ничего не делает и работает, только если требуется исполнить скрипт/обработчик или обработать событие.

## Асинхронность в Node.js модуле fs:

Вспомним как мы записывали файл в синхронном виде:

```
// Подключаем модуль файловой системы
const fs = require('fs')

// Классическая синхронная работа кода
fs.writeFileSync('list.txt', '1\n')
fs.writeFileSync('list.txt', '2\n', { flag: 'a' })
fs.writeFileSync('list.txt', '3\n', { flag: 'a' })
fs.writeFileSync('list.txt', '4\n', { flag: 'a' })
fs.writeFileSync('list.txt', '5', { flag: 'a' })
```

Пример асинхронная работа кода (эксперимент, некорректный спопоб):
```
fs.writeFile('message.txt', '1\n', { flag: 'a' }, (err) => { })
fs.writeFile('message.txt', '2\n', { flag: 'a' }, (err) => { })
fs.writeFile('message.txt', '3\n', { flag: 'a' }, (err) => { })
fs.writeFile('message.txt', '4\n', { flag: 'a' }, (err) => { })
fs.writeFile('message.txt', '5\n', { flag: 'a' }, (err) => { })
```

Пример записи файла в асинхронном виде (callback hell):
```
fs.writeFile('message.txt', '1\n', { flag: 'a' }, (err) => {
    if (err) throw err
    console.log('1!')
    fs.writeFile('message.txt', '2\n', { flag: 'a' }, (err) => {
        if (err) throw err
        console.log('2!')
        fs.writeFile('message.txt', '3\n', { flag: 'a' }, (err) => {
            if (err) throw err
            console.log('3!')
            fs.writeFile('message.txt', '4\n', { flag: 'a' }, (err) => {
                if (err) throw err
                console.log('4!')
                fs.writeFile('message.txt', '5\n', { flag: 'a' }, (err) => {
                    if (err) throw err
                    console.log('5!')
                })
            })
        })
    })
})
```

## Arguments и Rest parameters (остаточные параметры):
> Объект `arguments` — это подобный массиву объект, который содержит аргументы, переданные в функцию.

Пример функции с одним параметром, но вызовом со множеством параметров:
```
function check(params) {
    //arguments — псевдомассив аргументов, есть возможность использовать length, но нельзя использовать методы массива
    console.log(arguments)
    console.log(params)
}

check(50, 100, 150, 200)
```

Пример посложнее:
```
function getSomething(a, b) {
    if (arguments.length === 2) {
        console.log(`${a} or ${b}`)
    } else {
        let str = `${a} or ${b}.`
        for (let i = 2; i < arguments.length; i++) {
            str += ` ${arguments[i]}`
        }
        console.log(str)
    }
}

getSomething(1, 2, 3, 4, 5);
```

Rest параметры могут быть обозначены через три точки `...` 
Буквально это значит: «собери оставшиеся параметры и положи их в массив»

Пример:
```
function sum(a, b, ...args) {
  // args - массив всех аргументов,поданных после второго
  return args;
}

sum(1, 2); // [] 
sum(1, 2, 3, 4, 5); // [3, 4, 5] 
```

## План:
- Таймеры
- Очистка таймеров с помощью `clearInterval()` и `clearTimeout()`
- Разница выполнения кода через таймеры и в обычном виде
- Что такое `Event Loop`?
- Этапы `Event Loop` (бездействие > выполнение задачи > формирование очереди)
- Разобрать визуализацию `Event Loop` на примере: https://www.jsv9000.app/
- Общее понимание асинхронности в JS
- Асинхронные методы модуля `fs` (чтение, запись файлов)
- Вспоминть синхронное чтение файла, обсудить способ прочитать файл
- Познакомиться с асинхронным чтением файла
- Понять разницу между синхронным чтением и асинхронным
- `CallbackHell` что это?
- Сделать свой мини `CallbackHell`
- Попробовать избежать `CallbackHell`, асинхронные методы без callback