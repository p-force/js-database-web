const car = {
  model: "Toyota",
  year: 2017,

  show: function () {
    console.log(`${car.model}, год выпуска: ${car.year}`);
  },
};

const bike = {
  model: "BMW",
  year: 2022,

  show: function () {
    console.log(`${this.model}, год выпуска: ${this.year}`);
  },
};

const boat = {
  model: "Yamaha",
  year: 2021,

  show: function () {
    console.log(`${this.model}, год выпуска: ${this.year}`);
  },
}

car.show();
bike.show();
boat.show()


function showMeThis() {
  console.log(this);
}

const oleg = { name: "Олег", show: showMeThis };
const igor = { name: "Игорь", show: showMeThis };

oleg.show(); // { name: 'Олег', show: Function }
igor.show(); // { name: 'Игорь', show: Function }