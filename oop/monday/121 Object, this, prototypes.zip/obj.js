const obj1 = {
  'test 5': 5
} // через литерал
const obj2 = new Object() // через конструктор

const h = (v) => v;

obj1.x = 'This is X'
obj1.f = function (a, b) {
  return a + b
}

obj1.h = h

// console.log(obj1);
// console.log(obj1.f(4, 8));

delete obj1.x

const str = 'test 5'

// console.log(obj1);

// console.log(Object.values(obj1));

const ere = Object.values(obj1)[2] // [1,2,3]

// console.log(ere(2));

const myObject = { x: "first", y: "second", toString: 123 };

for (const key in myObject) {
  console.log(myObject[key]);
}

