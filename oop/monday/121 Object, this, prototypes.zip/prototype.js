const myObject = Object.create({ x: 1 });

const newProto = { n: () => console.log(123) }

// получить прототип объекта
Object.getPrototypeOf(myObject); // {x: 1}

console.log(Object.getPrototypeOf(myObject));

// // установить новый прототип объекта
Object.setPrototypeOf(myObject, newProto);

console.log(Object.getPrototypeOf(myObject));
// Object.getPrototypeOf(myObject); // {y: 2}