// функция-конструктор
function Person(name) {
  this.name = name;
}

// создать метод sayHi для прототипа на основе конструктора Person
Person.prototype.sayHi = function () {
  console.log(`Привет, я ${this.name}`);
};

const ivan = new Person("Иван"); // создание объекта через конструктор
ivan.sayHi(); // Привет, я Иван