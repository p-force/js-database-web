function showFullName(lastName, patronymic) {
  console.log(`${lastName} ${this.name} ${patronymic}, мне ${this.age} лет`);
}

const igor = { name: "Игорь", age: 22 };
const alex = { name: "Алексей", age: 24 };
const adam = { name: "Адам", age: 26 };

const staticArrArg = ["Иванов", "Сергеевич"]

showFullName.apply(adam, staticArrArg); // Иванов Игорь Сергеевич
