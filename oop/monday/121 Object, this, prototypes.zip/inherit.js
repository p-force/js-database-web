function Person(name) {
  this.name = name;
}

function Student(name, group) {
  Person.call(this, name); // вызываем конструктор прототипа-родителя
  this.group = group;
}

// задать Person.prototype как родителя для Student.prototype
Object.setPrototypeOf(Student.prototype, Person.prototype);

const ivan = new Student("Иван", "Еноты 2021 СПб");
console.log(ivan); // Student {name: "Иван", group: "Еноты 2021 СПб"}
console.log(ivan instanceof Student && ivan instanceof Person); // true