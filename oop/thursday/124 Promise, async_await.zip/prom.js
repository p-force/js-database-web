const fs = require('fs')

const readFile = new Promise((res, rej) => {
  fs.readFile('./data/names.txt', 'utf-8', (err, data) => {
    if (err) {
      return rej(err)
    } else {
      return res(data)
    }
  })
})

const writeFile = (path, content) => new Promise((res, rej) => {
  fs.writeFile(path, content, (err) => {
    if (err) {
      return rej(err)
    } else {
      return res('Write done!')
    }
  })
})


readFile
  // Short version
  .then(data => writeFile('./data/new.txt', data))
  .catch(err => console.log(err))
  .then(message => console.log(message))
  .catch(err => console.log(err))
  .finally(() => console.log('Ok!'))

  // Full version
  // .then(data => data.split('\n'))
  // .then((v) => console.log(v))

// writeFile('./data/2342.txt', '4234234')
//   .then(data => console.log(data))

