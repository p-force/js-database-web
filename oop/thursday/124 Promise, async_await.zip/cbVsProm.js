// Прочитали файл
// Изменили контент, добавили эмодзи
// Записали контент в новый файл
// Прочитали новый файл
const fs = require('fs')
const path = require('path')
const emo = require('./data/emo')

const readFile = (path) => {
  return new Promise((res, rej) => {
    fs.readFile(path, 'utf-8', (err, data) => {
      if (err) {
        return rej(err)
      } else {
        return res(data)
      }
    })
  })
}

const writeFile = (path, content) => new Promise((res, rej) => {
  fs.writeFile(path, content, (err) => {
    if (err) {
      return rej(err)
    } else {
      return res('Done!')
    }
  })
})

readFile('./data/names.txt')
  .then(data => {
    return data
      .split('\n')
      .map((name, index) => `${name} сегодня такой(-ая): ${emo[index]}`)
      .join('\n')
  })
  .then(string => writeFile('./data/newnew.txt', string))
  .then(mess => console.log(mess))