// const promise = new Promise((resolve, reject) => {
//   resolve('Burger!')
//   reject('Oops...')
// })

// console.log(promise);

const promise = new Promise((res, rej) => {
  if (Math.random() > 0.5) {
    res('Success');
  } else {
    rej('Error');
  }
});

// console.log(promise);

promise
  .then((data) => console.log(data))
  .catch((err) => console.log(err))
  .finally(() => {
    setTimeout(() => {
      console.clear()
    }, 1000);
  })
