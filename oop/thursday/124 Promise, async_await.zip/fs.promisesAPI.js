const fs = require('fs/promises')

// use Callback
// fs.readFile('./data/names.txt', 'utf-8', (err, data) => {
//   if (err) {
//     return rej(err)
//   } else {
//     return res(data)
//   }
// })

const content = fs.readFile('./data/dnames.txt', 'utf-8')

console.log(content);

content
  .then(o => console.log(o))
  .catch(e => console.log(e))

  