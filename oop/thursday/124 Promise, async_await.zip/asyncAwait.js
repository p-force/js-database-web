const fs = require('fs/promises')

const content = fs.readFile('./data/names.txt', 'utf-8')

// content
//   .then(o => console.log(o))
//   .catch(e => console.log(e))


const ex = async () => {
  const result = await content

  console.log(result);

  return 2022
  // throw 2021
}

ex()
  .then(data => console.log(data))
  .catch(err => console.log(err))