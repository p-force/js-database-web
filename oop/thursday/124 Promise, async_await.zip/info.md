## Promises и асинхронные операции:
> Promise — это объект (создаётся на основе класса Promise), представляющий результат успешного или неудачного завершения асинхронной операции.

> Асинхронная операция, это некоторое действие, которое выполняется независимо от окружающего ее кода, в котором она вызывается, не блокирует выполнение вызываемого (синхронного) кода.

## Конструкция объекта Promise:

> Callback переданный в конструкцию `new Promise`, называется исполнитель (`executor`). Когда Promise создаётся, она запускается автоматически. Аргументами в этом исполнителе являются два других callback'a `resolve` и `reject`.

Сам объект Promise может быть в трёх состояниях:
- вначале `pending` («ожидание»), 
- затем – одно из: `fulfilled` («выполнено успешно») или `rejected` («выполнено с ошибкой»)

Пример кода c успешным выполнением Promise:
```
const promise = new Promise((resolve, reject) => {
  resolve('Ok')
})
```

## Потребители Promises: then(), catch(), finally():

> Потребители это методы, которые могут взаимодействовать с результом Promise.

### then():

> Первый аргумент метода `.then` – функция, которая выполняется, когда промис переходит в состояние «выполнен успешно», и получает результат.

> Второй аргумент `.then` – функция, которая выполняется, когда промис переходит в состояние «выполнен с ошибкой», и получает ошибку.

### catch():

> Если мы хотели бы только обработать ошибку, то можно использовать `null` в качестве первого аргумента: `.then(null, errorHandlingFunction)`. Или можно воспользоваться методом `.catch(errorHandlingFunction)`, который сделает то же самое.

### finally():

> Вызов `.finally(f)` похож на `.then(f, f)`, в том смысле, что `f` выполнится в любом случае, когда промис завершится: успешно или с ошибкой.

> `finally` хорошо подходит для очистки, например остановки индикатора загрузки, его ведь нужно остановить вне зависимости от результата.

## Способы работы с модулем fs:

- синхронный (долгий, нерекомендуемый):
```
const data = fs.readFileSync(...)
```

- асинхронный с используванием callback:
```
fs.readFile(..., (err,  data) => {})
```

- асинхронный с использованием fs.promises:
```
fs.readFile(...).then(...).then(...)
```

## Статические методы класса Promise (методы которые запускаются относительно класса):

### В классе Promise есть набор статических методов:
- Promise.all()
- Promise.any()
- Promise.allSettled()
- Promise.race()
- Promise.resolve()
- Promise.reject()

### Promise.all():
Метод `Promise.all()` принимает массив промисов и возвращает новый промис.
Новый промис завершится, когда завершится весь переданный список промисов, и его результатом будет массив их результатов.

Пример кода:
```
Promise.all([
  new Promise(resolve => setTimeout(() => resolve(1), 3000)), // 1
  new Promise(resolve => setTimeout(() => resolve(2), 2000)), // 2
  new Promise(resolve => setTimeout(() => resolve(3), 1000))  // 3
]).then(data => console.log(data)) // [1, 2, 3]
```

Пример кода посложнее:
```
const fs = require('fs').promises

// массив названий файлов для чтения
const files = [
  'index.html',
  'style.css',
  'script.js'
];

// преобразуем массив названий файлов в массив промисов, которые нужно выполнить все
const arrPromises = files.map(file => fs.readFile(file, 'utf-8'));

// Promise.all() будет ожидать выполнения всех промисов
Promise.all(arrPromises)
  .then(readFiles => readFiles.forEach(
    file => console.log(file)
  ));
```

### Promise.any():

Метод `Promise.any()` принимает массив промисов и возвращает первый успешно завершившийся промис.

Пример кода:
```
Promise.any([
  new Promise(resolve => setTimeout(() => resolve(1), 3000)), // 1
  new Promise(resolve => setTimeout(() => resolve(2), 2000)), // 2
  new Promise(resolve => setTimeout(() => resolve(3), 1000))  // 3
]).then(data => console.log(data)) // 3
```


### Promise.allSettled():
Метод `Promise.allSettled()` всегда ждёт завершения всех промисов, независимо от ошибки (reject)

Пример кода:
```
const fs = require('fs').promises

// массив названий файлов для чтения
const files = [
  'index.html',
  'style.css',
  'script.js'
];

// преобразуем массив названий файлов в массив промисов, которые нужно выполнить все
const arrPromises = files.map(file => fs.readFile(file, 'utf-8'));

// Promise.allSettled() будет ожидать выполнения всех промисов и вернёт массив с информацией о каждом
Promise.allSettled(arrPromises)
  .then(readFiles =>
    readFiles.forEach(file => console.log(file.status))
  );
```

> Даже если в каком-то промисе сформируется ошибка, мы всё равно получим оставшиеся успешные. Логика «хоть что-нибудь».

### Promise.race():

Метод `Promise.race()` очень похож на `Promise.all()`, но ждёт только первый выполненный промис, из которого берёт результат (или ошибку). Логика "кто первый, с тем и работаем".

Пример кода:
```
// первый промис, который перейдёт в состояние resolve через 500 мс.
const promise1 = new Promise((resolve, reject) => {
  setTimeout(resolve, 500, 'one');
});

// второй промис, который перейдёт в состояние resolve через 100 мс.
const promise2 = new Promise((resolve, reject) => {
  setTimeout(resolve, 100, 'two');
});

// Promise.race() принимает в себя массив промисов, и самый первый успешный промис будет обработан
Promise.race([promise1, promise2]).then((value) => {
  console.log(value);
});
```

### Promise.resolve() / Promise.reject():
Методы `Promise.resolve()` и `Promise.reject()` редко используются в современном коде, так как синтаксис `async/await` в целом повторяет их функционал.
Но если возможности использовать `async/await` нет, то в целом эти методы будут нужны.

Пример кода:
```
// создаёт успешно выполненный промис с результатом 'a1'
const a1 = Promise.resolve('a1');

// это тоже самое, что:
const a2 = new Promise(resolve => resolve('a2'));

// создаёт промис, завершённый с ошибкой 'b1'
const b1 = Promise.reject('b1');

// это тоже самое, что:
const b2 = new Promise((resolve, reject) => reject('b2'));
```

## Промисификация:

> Преобразование функции, которая принимает callback, в функцию, которая возвращает объект Promise.

Пример кода:

```
const fs = require('fs');

function myReadFile(file, encoding) {
    return new Promise((resolve, reject) => {
        fs.readFile(file, encoding, (error, data) => {
            if (error) {
                return reject(error);
            }
            resolve(data);
        });
    });
}

myReadFile('./files/1.txt', 'utf8')
    .then(console.log)
    .catch(console.error);
```

## async/await:

Существует специальный синтаксис для работы с промисами, который называется `async/await`, основная цель которого упростить работу с промисами и исключть применение метода `.then()`

Ключевое слово `async` пишется перед определением функции, и меняет поведение функции таким образом, что возвращаемым значением становится промис + появляется возможность использовать `await`

Пример кода:
```
async function year() {
  return 2022;
}

year().then(console.log); // 2022
```

Пример кода с аналогом исполнения:
```
async function year() {
  return Promise.resolve(2022);;
}

year().then(console.log); // 2022
```

Ключевое слово `await` заставит интерпретатор JavaScript ждать до тех пор, пока промис справа от `await` не выполнится. После чего оно вернёт его результат, и выполнение кода продолжится.

Пример кода:
```
async function timer() {

  const promise = new Promise((resolve, reject) => {
    setTimeout(() => resolve("Booom!"), 3000)
  });

  const result = await promise; // будет ждать, пока промис не выполнится (*)

  console.log(result); // "Booom!"
}

timer();
```
> `await` нельзя использовать в обычных функциях и вне обёртки `async`

## Обработка ошибок в async/await:

Когда промис завершается успешно, `await` у промиса возвращает результат. Когда завершается с ошибкой – будет выброшено исключение. Как если бы на этом месте находилось выражение `throw`.

Пример кода:
```
async function someFunction() {
  await Promise.reject(new Error("Oops!"));
}
```

Пример кода с аналогом исполнения:
```
async function someFunction() {
  throw new Error("Oops!");
}
```

## Важное замечание, при работе плагина 'Code Runner':
### Чтение путей происходит с относительным путём!

Пример корректного чтения для 'Code Runner' (когда запуск делается из папки 'js', а читаем файл из папки 'data'):
```
fs.readFile('./data/list.txt', 'utf-8', (err, data) => { })
```

Пример корректного чтения при запуске через node filename (когда запуск делается из папки 'js', а читаем файл из папки 'data'):
```
fs.readFile('../data/list.txt', 'utf-8', (err, data) => { })
```

## План:
- Вспомним про Callback Hell
- Какие проблемы создаёт Callback Hell?
- Promise, что это? Как он решает проблему?
- Состояния Promise (pending, fulfilled, rejected)
- Пример Promise с использованием таймеров
- Методы объекта Promise `.then()`, `.catch()`, `.finally()`, наполнение очереди микро задач
- Статические методы класса Promise `.all()`, `.allSettled()`,`.race()`, `.resolve()`, `.reject()`
- Вспомить асинхронный метод чтения/записи файлов через модуль `fs`, написать пример
- Промисификация, что это и зачем?
- Сделать промисификацию чтения папки/файлов
- Промисифицированная версия `fs.promises`, зачем она?
- Написать чтение файлов через Promise
- Найти разницу между `fs` и `fs.promises`
- Проделать задачу с добавленим эмодзи через Promise
- Синтаксическая обёртка `async/await`, для работы с Promise