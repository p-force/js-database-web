const Man = require('./man');
const Salon = require('./salon');
const Car = require('./car')

const pavel = new Man('Pavel', 33, 6000000, [])
const salon = new Salon('AlianceGroup', [
  new Car('BMW', 9000000, 2022),
  new Car('Mercedes', 20000000, 2022),
  new Car('Mazda', 4500000, 2022),
  new Car('Lada Vesta', 1000000, 2020),
], 0)


console.log(pavel, salon);

pavel.buyCar('Lada Vesta', salon)
pavel.buyCar('Mazda', salon)
pavel.buyCar('Mercedes', salon)

console.log(pavel, salon);

Man.hello()

console.log(Man.info);