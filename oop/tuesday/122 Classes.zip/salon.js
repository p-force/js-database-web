class Salon {
  constructor(title, cars, money) {
    this.title = title;
    this.cars = cars;
    this.money = money;
  }
}

module.exports = Salon;