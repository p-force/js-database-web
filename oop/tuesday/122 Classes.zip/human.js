// Human
class Human {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }
}

module.exports = Human;