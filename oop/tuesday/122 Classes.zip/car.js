class Car {
  constructor(model, price, year) {
    this.model = model;
    this.price = price;
    this.year = year;
  }
}

module.exports = Car;