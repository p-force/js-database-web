class Test {
  // приватный метод
  #privateMethod() {
    return (this.number * this.number)
  }

  constructor(number) {
    this.number = number;
  }
  
  square() {
    return this.#privateMethod()
  }
}

class Child extends Test {

  constructor(number, value) {
    super(number)
    this.value = value
  }
}

const child = new Child(20, 'werw')

