## Class:
  После появления стандарта ES2015 (ES6) в JavaScript появился новый способ определения объектов - с помощью классов. Класс представляет описание объекта, его состояния и поведения, а объект является экземпляром класса.

### Пример класса:
```
class ClassExample {
  constructor(params) {
    this.params = params
  }

  classMethod() {
    console.log(this.params);
  }
}

const instance = new ClassExample('example') // ClassExample { params: 'example' }
```
### Пример наследования класса (множество аргументов в конструкторе):
```
class ClassExample {
  constructor(params) {
    this.params = params
  }

  classMethod() {
    console.log(this.params);
  }
}

const instanceClassExample = new ClassExample('example') // ClassExample { params: 'example' }

class ChildClass extends ClassExample {
  constructor(params, nativeParams) {
    super(params)
    this.nativeParams = nativeParams    
  }
}

const instanceChildClass = new ChildClass('example', 'native') // ChildClass { params: 'example', nativeParams: 'native' }

```

### Пример наследования класса (один аргумент в конструкторе):

```
class ClassExample {
  constructor(option = {}) {
    this.params = option.params
  }

  classMethod() {
    console.log(this.params);
  }
}

class ChildClass extends ClassExample {
  constructor(option = {}) {
    super(option)
    this.nativeParams = option.nativeParams    
  }
}

const instanceChildClass = new ChildClass({params: 'example', nativeParams: 'native'}) // ChildClass { params: 'example', nativeParams: 'native' }
```

### Статические методы класса:
```
class Info {
  constructor(command) {
    this.command = command;
  }
  static runCommand(obj) {
    return alert(obj.command);
  }
}
const commandExample = new Info('node app.js');

// вызов статического метода не требует экземпляра класса
Info.runCommand(commandExample);
```

### Геттеры и сеттеры в классах + приватные свойства:
```
class Test {
  #privatX; // приватное свойство

  constructor(value) {
    this.#privatX = value
  }

  get x() {
    return this.#privatX
  }

  set x(value) {
    if (value > 5) {
      this.#privatX = value
    } else {
      console.log('Too small value');
    }
  }
}

const test1 = new Test('Example!')
```

### Приватные методы (запускаются через публичные):

```
class Test {
 // приватный метод
 #privatMethod() {
   return (this.number * this.number)
 }

 constructor(number) {
   this.number = number;
 }
 
 square() {
   return this.#privatMethod()
 }
}
```