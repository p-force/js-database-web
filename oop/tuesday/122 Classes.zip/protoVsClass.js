// Proto
function StudentP(name, age) {
  this.name = name;
  this.age = age;
}

StudentP.prototype.getMyYear = function () {
  return `Меня зовут ${this.name}, я родился в ${new Date().getFullYear() - this.age} году`
}


// Classes
// объявление класса
class StudentC {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }
}

class Human {
  constructor({ name }) {
    this.name = name
  }
}

// object in params
class StudentObjectInParams extends Human {
  constructor({ name, z, lastName } = {}) {
    super({ name }) // this.name = name
    this.age = z;
    this.lastName = lastName;
  }

  getMyYear() {
    return `Меня зовут ${this.name}, я родился в ${new Date().getFullYear() - this.age} году`
  }
}

// создание экземпляра (instance) от класса
const anton = new StudentP('Антон', 24);
const kirill = new StudentC('Кирилл', 28);
const daria = new StudentObjectInParams({ name: 'Daria', z: 26, lastName: 'Goncharova' })

// console.log(daria);

daria.age = 22

// console.log(daria);

console.log(anton.getMyYear());
console.log(daria.getMyYear());