const Human = require("./human");

class Man extends Human {
  constructor(name, age, money, cars) {
    super(name, age)
    this.money = money;
    this.cars = cars;
  }

  static info = 2020

  static hello() {
    console.log('Hello!');
  }

  buyCar(carModel, salon) {
    const wantCar = salon.cars.find(car => car.model === carModel)

    this.money = this.money - wantCar.price;
    this.cars.push(wantCar.model)

    salon.cars = salon.cars.filter(el => el.model !== carModel);
    salon.money += wantCar.price;
  }
}

module.exports = Man;