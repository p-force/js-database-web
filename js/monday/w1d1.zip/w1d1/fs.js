const fs = require('fs');

const text = fs.readFileSync('./text.txt', 'utf8');
console.log(text);
fs.writeFileSync('./text2.txt', `${text} Wowow`);
// fs.writeFileSync('./text2.txt', 'Blabla');
fs.appendFileSync('./text2.txt', '\nBlabla');
