const oneLinerJoke = require('one-liner-joke');

const getRandomJoke = oneLinerJoke.getRandomJoke();
const bla = 'bla';

console.log(process.argv);

// console.log(getRandomJoke);
module.exports = { getRandomJoke, bla };
// {getRandomJoke: getRandomJoke, bla:bla}
