const { getRandomJoke, bla } = require('../folderForIndex/index'); // {getRandomJoke: getRandomJoke, bla:bla}
// const getRandomJoke = {}.getRandomJoke;
// const bla = {}.bla

console.log(bla);
