const arr = [1,65,3,87,21,0]
const arrSorted = [1,2,3,4,5,6,7,8,9]