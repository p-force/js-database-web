// ССЫЛОЧНЫЙ ТИП

// const a1 = [2,3,4]
const a1 = [{score:12}, {score:13}, {score:19}]
const a0 = [12,13,14]
const a2 = a1
// console.log(a1===a2);

// a1[0]=10000
// console.log(a1);
// console.log(a2);

// const a3=[...a1,...a0] // поверхностное копирование
// const a3=[...a1] 
// // console.log(a3);
// console.log(a3===a1);
// console.log(a3);
const deepCopy = JSON.parse(JSON.stringify(a1))
a1[0].score=10000
console.log(deepCopy);
console.log(a1);