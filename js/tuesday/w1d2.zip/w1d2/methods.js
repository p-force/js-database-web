const people = [
    {
        name: 'Bob',
        age:12
    },
     {
        name: 'Beb',
        age:10
    },
 {
        name: 'Bib',
        age:14
    }
]

// FILTER
const fn = (el)=>el.age<11
// console.log(people.some(fn));
// console.log(people.every(fn));
const newArr = people.filter((el)=>el.age >11)
// console.log(newArr);
// console.log(people);

// FILTER

const todos = 
[
{id:1, title: 'hello'}, 
{id:2, title: 'hello2'},
{id:3, title: 'hello3'}
]


// function delTodo(arr,id) {
//    return arr.filter(el=>el.id !== id )
// }

// console.log(delTodo(todos,3));

// // MAP
function addStatus(arr) {
    return arr.map(el=>{
        return {...el, status:false}
        // el['status']=false
        // console.log(el);
    })
}
console.log(addStatus(todos));
console.log(todos);

// const arr = [1,2,3,4]
// const arr2 = arr.map(el=> el*2)
// console.log(arr);
// console.log(arr2);


// console.log(people.sort((curr,nex)=> curr.age - nex.age));


// REDUCE

// const arr = [1,2,3,4]

// const res = arr.reduce((acc,val)=>{return acc + val},2 )

// // acc = 2, val = 1 -> return 3
// // acc = 3, val = 2 -> return 5
// // acc = 5, val = 3 -> return 8
// // acc = 8, val = 4 -> return 12


// const res = arr.reduce((acc,val)=>{return acc + val})

// // acc=1, val=2 -> 3
// // acc=3 val=3 -> 6
// // acc=6 val=4 -> 10

// console.log(res);

// const arr = [21,42,73,49,52,16]

// const res = arr.reduce((acc,val,i)=>{
//     const tmp = Math.floor(i/3) // 0,0,1,1,2,2
//     if(!Array.isArray(acc[tmp])){
//     acc[tmp]=[val]
//     } else {
//     acc[tmp].push(val)
//     }
//     return acc
// },[])

// // acc=[] val=21 tmp=0 -> acc=[[21]]
// // acc=[[21]] val=42 tmp=0 -> [[21,42]]

// console.log(res);


const arr = [21,42,73,49,52,16]
// for (let i = 0; i < arr.length; i++) {
//     if (arr[i]===42){
//         return console.log("SUCCESS");
//     } else {
//         console.log('no success');
//     }
    
// }

// arr.forEach((el)=> {
//     if (el === 42) {
//          console.log("SUCCESS"); // НЕ РАБОТАЕТ
//     } else {
//         console.log('no success');
//     }
// } )