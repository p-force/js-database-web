const a = [1,2,'bla', true, ()=> {console.log('hello')}]
// a[4]()

// const arr1 = [1,2,3]
// const arr2 = [1,2,3]

// console.log(arr1===arr2);
// console.log([]===[]);

// const res = a.push(1000)
// console.log(res);
// console.log(a);

// function add(arr,el) {
//  arr.push(el)
//  return arr
// }

// console.log(add([1,2,3], 55));

// const names = "Igor,Anna,Vasya";
//   const arr = names.split(',');
//   console.log(arr.join());


const arr = [1,2,3,4,5,6]
// console.log(arr.slice(1,3));
// console.log(arr);
// 2,3,4
// 2,3


// const res = arr.splice(2,2,1000) //(индекс начала, количество элементов, вставка)
// console.log(res); // удалённые элементы
// console.log(arr);// [1,2,1000,5,6]

console.log(typeof arr);
console.log(Array.isArray(arr));